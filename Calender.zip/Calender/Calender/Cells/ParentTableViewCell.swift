//
//  ParentTableViewCell.swift
//  Calender
//
//  Created by Rashmi Gupta on 28/06/24.
//

import Foundation
import UIKit

protocol ParentTableViewCellProtcol: AnyObject {
    func didSelectDate(month: String, day: Int)
}

class ParentTableViewCell: UITableViewCell {
    static let identifier = "ParentTableViewCell"
    var monthName = ""
    var numberOfDays = 30
    
    weak var delegate: ParentTableViewCellProtcol?
    
    private let calenderCollectionView: UICollectionView = {
       let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        return collectionView
    }()
    
    private let monthLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        calenderCollectionView.delegate = self
        calenderCollectionView.dataSource = self
        calenderCollectionView.register(CalenderCell.self, forCellWithReuseIdentifier: CalenderCell.identifier)
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setup() {
        contentView.addSubview(monthLabel)
        contentView.addSubview(calenderCollectionView)
        
        NSLayoutConstraint.activate([
            monthLabel.topAnchor.constraint(equalTo: contentView.topAnchor),
            monthLabel.bottomAnchor.constraint(equalTo: calenderCollectionView.topAnchor, constant: -5),
            monthLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
        ])
        
        
        NSLayoutConstraint.activate([
            calenderCollectionView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            calenderCollectionView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            calenderCollectionView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
        ])
    }
    
    func configureCell(monthName: String) {
        monthLabel.text = monthName
        self.monthName = monthName
    }
}

extension ParentTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return numberOfDays
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: CalenderCell.identifier,
            for: indexPath
        ) as? CalenderCell else {
            return UICollectionViewCell()
        }
        let day = indexPath.item % 30 + 1
        cell.configureCell(date: "\(day)")
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width / 7
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.didSelectDate(month: monthName, day: indexPath.row)
    }
}


