//
//  ViewController.swift
//  Calender
//
//  Created by Rashmi Gupta on 28/06/24.
//

import UIKit

class ViewController: UIViewController {
    
    let monthArray = ["JAN", "FEB", "MARCH", "APRIL", "MAY", "June", "JULY", "AUGUST", "SEPTEMBER", "OCT", "NOV", "DEC"]
    
    private let parentTableView: UITableView = {
       let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.estimatedRowHeight = 400
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        parentTableView.delegate = self
        parentTableView.dataSource = self
        
        parentTableView.register(ParentTableViewCell.self, forCellReuseIdentifier: ParentTableViewCell.identifier)
        setup()
        
        scrollToCurrentDate()
    }
    
    func setup() {
        view.addSubview(parentTableView)
        
        NSLayoutConstraint.activate([
            parentTableView.topAnchor.constraint(equalTo: view.topAnchor),
            parentTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            parentTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            parentTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    func scrollToCurrentDate() {
        let now = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "LLLL"
        let nameOfMonth = dateFormatter.string(from: now)
        
        let index = monthArray.firstIndex(of: nameOfMonth) ?? 0
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.parentTableView.scrollToRow(at: IndexPath(row: index, section: 0), at: .top, animated: true)
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return monthArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: ParentTableViewCell.identifier,
            for: indexPath
        ) as? ParentTableViewCell else {
            return UITableViewCell()
        }
        cell.delegate = self
        cell.configureCell(monthName: monthArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.estimatedRowHeight
    }
}

extension ViewController: ParentTableViewCellProtcol {
    func didSelectDate(month: String, day: Int) {
        navigationController?.pushViewController(DetailPageViewController(), animated: true)
    }
}
