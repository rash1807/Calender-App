//
//  DetailsPageViewController.swift
//  Calender
//
//  Created by Rashmi Gupta on 28/06/24.
//

import Foundation
import UIKit

class DetailPageViewController: UIViewController {
    
}

